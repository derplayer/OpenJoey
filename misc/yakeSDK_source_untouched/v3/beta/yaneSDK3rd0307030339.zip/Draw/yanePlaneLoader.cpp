#include "stdafx.h"
#include "yanePlaneLoader.h"

//////////////////////////////////////////////////////////////////////////////

namespace yaneuraoGameSDK3rd {
namespace Draw {

CPlaneLoader::CPlaneLoader()
{
	SetColorKey(ISurface::makeRGB(0,255,0));
	SetFactory(CPlane::GetFactory());	//	default��factory��ݒ�
}

/*smart_ptr<ISurface>*/
CPlane CPlaneLoader::GetPlane(int nNo){		///	�v���[���̎擾

	Load(nNo);

	smart_obj obj;
	if (GetIDObjectManager()->getObject(nNo,obj)!=0){
		//	���ꂪ������Ȃ����Ƃ͖����͂�����..
		return CPlane(smart_ptr<ISurface>(new CSurfaceNullDevice));
	}

	smart_ptr<ISurface> p = *(smart_ptr<ISurface>*)((*(smart_ptr<CLoadCacheInfo>*)obj.get())->pObj.get());
	if (IsRGBColorKey()){
		p->SetColorKey(GetColorKey());
	} else {
		p->SetColorKeyPos(m_nColorKeyPosX,m_nColorKeyPosY);
	}
	return CPlane(p);
}

///	nNo�̃t�@�C�������擾
string	CPlaneLoader::GetFileName(int nNo){

	smart_obj obj;
	if (GetIDObjectManager()->getObject(nNo,obj)!=0){
		//	���ꂪ������Ȃ����Ƃ͖����͂�����..
		return "";
	}

	return (*(smart_ptr<CLoadCacheInfo>*)obj.get())->strFileName;
}

//////////////////////////////////////////////////////////////////////////////

LRESULT		CPlaneLoader::InnerLoad(const smart_obj& obj){

	CLoadCacheInfo& info = *(*(smart_ptr<CLoadCacheInfo>*)obj.get()).get();

	string strFileName(info.strFileName);

	info.pObj.Add(new smart_ptr<ISurface>(GetFactory()->CreateInstance()));
	LRESULT lr = (*(smart_ptr<ISurface>*)info.pObj.get())->Load(strFileName);

	//	�G���[���[�h�Ȃ�΁ANullDevice��Ԃ�
	if (lr!=0){
		(*(smart_ptr<ISurface>*)info.pObj.get())
			= smart_ptr<ISurface>(new CSurfaceNullDevice);
	}

	return lr;
}

} // end of namespace Draw
} // end of namespace yaneuraoGameSDK3rd
