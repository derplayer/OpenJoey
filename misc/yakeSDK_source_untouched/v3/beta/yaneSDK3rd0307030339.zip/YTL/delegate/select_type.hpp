/**
 *	Type Selecting Template Class
 *	programmed by ENRA		'02/10/06
 */

#ifndef __YTL_DELEGATE_SELECT_TYPE_HPP__
#define __YTL_DELEGATE_SELECT_TYPE_HPP__

#ifdef USE_yaneSDKdelegate
#ifdef _MSC_VER

namespace yaneuraoGameSDK3rd {
namespace YTL {
namespace YTLdelegate {

//	i��0�ȊO�Ȃ�T�A0�Ȃ�F��type�^�Ƃ��ĕԂ�
template<int i, typename T, typename F>
class select_type {
	template<int> struct inner {
		typedef T type;
	};
	template<> struct inner<0> {
		typedef F type;
	};
public:
	typedef typename inner<i>::type type;
};

} // end of namespace YTLdelegate
} // end of namespace YTL
} // end of namespace yaneuraoGameSDK3rd

#endif	//	USE_yaneSDKdelegate
#endif	//	_MSC_VER

#endif // __YTL_DELEGATE_SELECT_TYPE_HPP__
