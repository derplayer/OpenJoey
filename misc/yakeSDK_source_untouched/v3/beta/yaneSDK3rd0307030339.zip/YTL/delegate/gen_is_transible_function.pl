#
#	Function Transibility Testing Template Class Generator
#		programmed by ENRA	'03/06/25
#

if ($#ARGV < 0) {
  print "Usage: perl gen_is_transible_function <number of arguments>\n";
  exit;
}

open OUT, ">is_transible_function.hpp";

print OUT "/**\n";
print OUT " *\tFunction Transibility Testing Template Class\n";
print OUT " *\t\tprogrammed by ENRA\t'03/06/25\n";
print OUT " */\n";
print OUT "\n";
print OUT "#ifndef __YTL_DELEGATE_IS_TRANSIBLE_FUNCTION_HPP__\n";
print OUT "#define __YTL_DELEGATE_IS_TRANSIBLE_FUNCTION_HPP__\n";
print OUT "\n";
print OUT "#ifdef USE_yaneSDKdelegate\n";
print OUT "#ifdef _MSC_VER\n";
print OUT "\n";
print OUT "#include \"yes_no_type.hpp\"\n";
print OUT "#include \"is_same.hpp\"\n";
print OUT "#include \"is_convertible.hpp\"\n";
print OUT "#include \"select_type.hpp\"\n";
print OUT "\n";
print OUT "namespace yaneuraoGameSDK3rd {\n";
print OUT "namespace YTL {\n";
print OUT "namespace YTLdelegate {\n";
print OUT "\n";

$TotalArgs = $ARGV[0];
print OUT "//\t$TotalArgs�����֐��܂ł̓]���\\���`�F�b�N���\\\n";
print OUT "template<class From, typename To>\n";
print OUT "struct is_transible_function\n";
print OUT "{\n";

for ($CurrentArgs=0; $CurrentArgs<=$TotalArgs; ++$CurrentArgs) {
	for ($IsToClassMethod=0; $IsToClassMethod<=1; ++$IsToClassMethod) {
		for ($IsFromClassMethod=0; $IsFromClassMethod<=1; ++$IsFromClassMethod) {
			for ($IsToConstClassMethod=0; $IsToConstClassMethod<=$IsToClassMethod; ++$IsToConstClassMethod) {
				for ($IsFromConstClassMethod=0; $IsFromConstClassMethod<=$IsFromClassMethod; ++$IsFromConstClassMethod) {
					#�R�����g
					print OUT "\t//\t$CurrentArgs����: ";
					if ( $IsFromConstClassMethod ) { print OUT "const "; }
					if ( $IsFromClassMethod ) { print OUT "class method"; }
					else { print OUT "static method"; }
					print OUT " �� ";
					if ( $IsToConstClassMethod ) { print OUT "const "; }
					if ( $IsToClassMethod ) { print OUT "class method"; }
					else { print OUT "static method"; }
					print OUT "\n";

					#�֐��錾
					print OUT "\ttemplate<";
					if ( $IsFromClassMethod ) { print OUT "class fC,"; }
					if ( $IsToClassMethod ) { print OUT "class tC,"; }
					print OUT "typename fR, typename tR";
					for ($i=1; $i<=$CurrentArgs; ++$i) {
						print OUT ", typename fA$i, typename tA$i";
					}
					print OUT ">\n";
					print OUT "\tstatic yes_type check(fR(";
					if ( $IsFromClassMethod ) { print OUT "fC::"; }
					print OUT "*from)(";
					for ($i=1; $i<=$CurrentArgs; ++$i) {
						print OUT "fA$i";
						if ( $i!=$CurrentArgs ) { print OUT ","; }
					}
					print OUT ")";
					if ( $IsFromConstClassMethod ) { print OUT "const"; }
					print OUT ", tR(";
					if ( $IsToClassMethod ) { print OUT "tC::"; }
					print OUT "*to)(";
					for ($i=1; $i<=$CurrentArgs; ++$i) {
						print OUT "tA$i";
						if ( $i!=$CurrentArgs ) { print OUT ","; }
					}
					print OUT ")";
					if ( $IsToConstClassMethod ) { print OUT "const"; }
					print OUT ", typename select_type<is_same<fR,void>::result||is_convertible<tR,fR>::result,yes_type,no_type>::type";
					for ($i=1; $i<=$CurrentArgs; ++$i) {
						print OUT ", typename is_convertible<fA$i,tA$i>::type";
					}
					print OUT ", ...);\n";
				}
			}
		}
	}
}

print OUT "\n";
print OUT "\tstatic no_type check(...);\n";
print OUT "\n";
print OUT "\tenum { result = sizeof(yes_type)==sizeof(check((From)0,(To)0,yes_type()";
for ($i=1; $i<=$TotalArgs; ++$i) {
	print OUT ",yes_type()";
}
print OUT ")), };\n";
print OUT "\ttypedef typename select_type<result!=0, yes_type, no_type>::type type;\n";
print OUT "};\n";

print OUT "\n";
print OUT "} // end of namespace YTLdelegate\n";
print OUT "} // end of namespace YTL\n";
print OUT "} // end of namespace yaneuraoGameSDK3rd\n";
print OUT "\n";
print OUT "#endif	//	USE_yaneSDKdelegate\n";
print OUT "#endif	//	_MSC_VER\n";
print OUT "\n";
print OUT "#endif // __YTL_DELEGATE_IS_TRANSIBLE_FUNCTION_HPP__\n";

close OUT