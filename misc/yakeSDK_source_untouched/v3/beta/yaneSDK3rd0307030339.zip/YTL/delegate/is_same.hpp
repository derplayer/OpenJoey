/**
 *	Type Identity Testing Template Class
 *	programmed by ENRA		'02/10/06
 */

#ifndef __YTL_DELEGATE_IS_SAME_HPP__
#define __YTL_DELEGATE_IS_SAME_HPP__

#ifdef USE_yaneSDKdelegate
#ifdef _MSC_VER

namespace yaneuraoGameSDK3rd {
namespace YTL {
namespace YTLdelegate {

///	L��R�̌^�������Ȃ��true��result�l�Ƃ��ĕԂ�
template<typename L, typename R>
struct is_same {
	template<typename T> struct inner {
		enum { result = false };
	};
	template<> struct inner<R> {
		enum { result = true };
	};
	enum { result = inner<L>::result };
};

} // end of namespace YTLdelegate
} // end of namespace YTL
} // end of namespace yaneuraoGameSDK3rd

#endif	//	USE_yaneSDKdelegate
#endif	//	_MSC_VER

#endif // __YTL_DELEGATE_IS_SAME_HPP__
