/**
 *	Functor Template Class
 *		programmed by ENRA		'02/10/06
 *		reprogrammed by ENRA	'03/06/23
 *	
 *	version 1.29  2003/06/26 18:09:34
 */

#ifndef __YTL_DELEGATE_FUNCTOR_HPP__
#define __YTL_DELEGATE_FUNCTOR_HPP__

#ifdef USE_yaneSDKdelegate
#ifdef _MSC_VER

namespace yaneuraoGameSDK3rd {
namespace YTL {
namespace YTLdelegate {

//	�}�N�����g����functor�N���X��錾����
#define DELEGATE_FUNCTOR_IMPREMENTS(ARGS, FUNCTION_ARG1, FUNCTION_ARG2, COMMA) \
template<typename R, class A> \
struct functor_r##ARGS { \
	typedef R result_type; \
	typedef A arguments_type; \
	template<class T, class F> struct class_method_invoker { \
		struct info_type { \
			info_type(const T& _t, F _f) : t(_t), f(_f) {}; \
			const T& t; \
			F		 f; \
		}; \
		inline static result_type invoke(const smart_obj& pInfo COMMA FUNCTION_ARG1) { \
			const info_type& _info = **((const smart_ptr<info_type>*)pInfo.get()); \
			return (_info.t.*_info.f)(FUNCTION_ARG2); \
		} \
	}; \
	template<class F> struct static_method_invoker { \
		struct info_type { \
			info_type(F _f) : f(_f) {}; \
			F f; \
		}; \
		inline static result_type invoke(const smart_obj& pInfo COMMA FUNCTION_ARG1) { \
			const info_type& _info = **((const smart_ptr<info_type>*)pInfo.get()); \
			return (_info.f)(FUNCTION_ARG2); \
		} \
	}; \
	struct null_invoker { \
		inline static result_type invoke(const smart_obj& COMMA FUNCTION_ARG1) { return result_type(); } \
	}; \
	functor_r##ARGS() : invoke_function(&null_invoker::invoke) {}; \
	functor_r##ARGS(const functor_r##ARGS& f) \
		: invoke_function(f.invoke_function), invoke_info(f.invoke_info) {}; \
	inline result_type operator() (FUNCTION_ARG1) const { \
		return invoke_function(invoke_info COMMA FUNCTION_ARG2); \
	} \
	typedef result_type (functor_r##ARGS::*operator_type)(FUNCTION_ARG1) const; \
protected: \
	typedef result_type (*invoke_function_type)(const smart_obj& COMMA FUNCTION_ARG1); \
	invoke_function_type	invoke_function; \
	smart_obj	invoke_info; \
}; \
\
template<typename R, class A> \
struct functor_nr##ARGS { \
	typedef R result_type; \
	typedef A arguments_type; \
	template<class T, class F> struct class_method_invoker { \
		struct info_type { \
			info_type(const T& _t, F _f) : t(_t), f(_f) {}; \
			const T& t; \
			F		 f; \
		}; \
		inline static result_type invoke(const smart_obj& pInfo COMMA FUNCTION_ARG1) { \
			const info_type& _info = **((const smart_ptr<info_type>*)pInfo.get()); \
			(_info.t.*_info.f)(FUNCTION_ARG2); \
		} \
	}; \
	template<class F> struct static_method_invoker { \
		struct info_type { \
			info_type(F _f) : f(_f) {}; \
			F f; \
		}; \
		inline static result_type invoke(const smart_obj& pInfo COMMA FUNCTION_ARG1) { \
			const info_type& _info = **((const smart_ptr<info_type>*)pInfo.get()); \
			(_info.f)(FUNCTION_ARG2); \
		} \
	}; \
	struct null_invoker { \
		inline static result_type invoke(const smart_obj& COMMA FUNCTION_ARG1) {} \
	}; \
	functor_nr##ARGS() : invoke_function(&null_invoker::invoke) {}; \
	functor_nr##ARGS(const functor_nr##ARGS& f) \
		: invoke_function(f.invoke_function), invoke_info(f.invoke_info) {}; \
	inline result_type operator() (FUNCTION_ARG1) const { \
		invoke_function(invoke_info COMMA FUNCTION_ARG2); \
	} \
	typedef result_type (functor_nr##ARGS::*operator_type)(FUNCTION_ARG1) const; \
protected: \
	typedef result_type (*invoke_function_type)(const smart_obj& COMMA FUNCTION_ARG1); \
	invoke_function_type	invoke_function; \
	smart_obj	invoke_info; \
};

//	�J���}���܂߂ă}�N���̈����Ƃ��Ďw�肵�����ꍇ�A
//	����ȃ}�N�����g��˂΂Ȃ�Ȃ��c(��_�G)�m
#define NON_LITERAL() 
#define COMMA() ,
#define LITERAL1(_1) _1
#define LITERAL2(_1,_2) LITERAL1(_1),##_2
#define LITERAL3(_1,_2,_3) LITERAL2(_1,_2),##_3
#define LITERAL4(_1,_2,_3,_4) LITERAL3(_1,_2,_3),##_4
#define LITERAL5(_1,_2,_3,_4,_5) LITERAL4(_1,_2,_3,_4),##_5
#define LITERAL6(_1,_2,_3,_4,_5,_6) LITERAL5(_1,_2,_3,_4,_5),##_6
#define LITERAL7(_1,_2,_3,_4,_5,_6,_7) LITERAL6(_1,_2,_3,_4,_5,_6),##_7
#define LITERAL8(_1,_2,_3,_4,_5,_6,_7,_8) LITERAL7(_1,_2,_3,_4,_5,_6,_7),##_8
#define LITERAL9(_1,_2,_3,_4,_5,_6,_7,_8,_9) LITERAL8(_1,_2,_3,_4,_5,_6,_7,_8),##_9
#define LITERAL10(_1,_2,_3,_4,_5,_6,_7,_8,_9,_10) LITERAL9(_1,_2,_3,_4,_5,_6,_7,_8,_9),##_10
DELEGATE_FUNCTOR_IMPREMENTS(0, NON_LITERAL(), NON_LITERAL(), NON_LITERAL());
DELEGATE_FUNCTOR_IMPREMENTS(1, LITERAL1(typename A::A1 a1), LITERAL1(a1), COMMA());
DELEGATE_FUNCTOR_IMPREMENTS(2, LITERAL2(typename A::A1 a1,typename A::A2 a2), LITERAL2(a1,a2), COMMA());
DELEGATE_FUNCTOR_IMPREMENTS(3, LITERAL3(typename A::A1 a1,typename A::A2 a2,typename A::A3 a3), LITERAL3(a1,a2,a3), COMMA());
DELEGATE_FUNCTOR_IMPREMENTS(4, LITERAL4(typename A::A1 a1,typename A::A2 a2,typename A::A3 a3,typename A::A4 a4), LITERAL4(a1,a2,a3,a4), COMMA());
DELEGATE_FUNCTOR_IMPREMENTS(5, LITERAL5(typename A::A1 a1,typename A::A2 a2,typename A::A3 a3,typename A::A4 a4,typename A::A5 a5), LITERAL5(a1,a2,a3,a4,a5), COMMA());
DELEGATE_FUNCTOR_IMPREMENTS(6, LITERAL6(typename A::A1 a1,typename A::A2 a2,typename A::A3 a3,typename A::A4 a4,typename A::A5 a5,typename A::A6 a6), LITERAL6(a1,a2,a3,a4,a5,a6), COMMA());
DELEGATE_FUNCTOR_IMPREMENTS(7, LITERAL7(typename A::A1 a1,typename A::A2 a2,typename A::A3 a3,typename A::A4 a4,typename A::A5 a5,typename A::A6 a6,typename A::A7 a7), LITERAL7(a1,a2,a3,a4,a5,a6,a7), COMMA());
DELEGATE_FUNCTOR_IMPREMENTS(8, LITERAL8(typename A::A1 a1,typename A::A2 a2,typename A::A3 a3,typename A::A4 a4,typename A::A5 a5,typename A::A6 a6,typename A::A7 a7,typename A::A8 a8), LITERAL8(a1,a2,a3,a4,a5,a6,a7,a8), COMMA());
DELEGATE_FUNCTOR_IMPREMENTS(9, LITERAL9(typename A::A1 a1,typename A::A2 a2,typename A::A3 a3,typename A::A4 a4,typename A::A5 a5,typename A::A6 a6,typename A::A7 a7,typename A::A8 a8,typename A::A9 a9), LITERAL9(a1,a2,a3,a4,a5,a6,a7,a8,a9), COMMA());
DELEGATE_FUNCTOR_IMPREMENTS(10,LITERAL10(typename A::A1 a1,typename A::A2 a2,typename A::A3 a3,typename A::A4 a4,typename A::A5 a5,typename A::A6 a6,typename A::A7 a7,typename A::A8 a8,typename A::A9 a9,typename A::A10 a10), LITERAL10(a1,a2,a3,a4,a5,a6,a7,a8,a9,a10), COMMA());
#undef NON_LITERAL
#undef COMMA
#undef LITERAL1
#undef LITERAL2
#undef LITERAL3
#undef LITERAL4
#undef LITERAL5
#undef LITERAL6
#undef LITERAL7
#undef LITERAL8
#undef LITERAL9
#undef LITERAL10
#undef DELEGATE_FUNCTOR_IMPREMENTS


///	�g��Ȃ��Ƃ�������\���^
typedef void void_t;	//	�G���[���b�Z�[�W����� void �ɂ��Ƃ�(�L�[`)y-~~

///	�����̌^���܂Ƃ߂邽�߂̃e���v���[�g�N���X
template<
	typename A1	 = void_t,
	typename A2	 = void_t,
	typename A3	 = void_t,
	typename A4	 = void_t,
	typename A5	 = void_t,
	typename A6	 = void_t,
	typename A7	 = void_t,
	typename A8	 = void_t,
	typename A9	 = void_t,
	typename A10 = void_t
>
struct args_type {
	typedef A1  A1;
	typedef A2  A2;
	typedef A3  A3;
	typedef A4  A4;
	typedef A5  A5;
	typedef A6  A6;
	typedef A7  A7;
	typedef A8  A8;
	typedef A9  A9;
	typedef A10 A10;
	enum { args_num = ((is_same<A1 ,void_t>::result) ? 0 : 1
					+ ((is_same<A2 ,void_t>::result) ? 0 : 1
					+ ((is_same<A3 ,void_t>::result) ? 0 : 1
					+ ((is_same<A4 ,void_t>::result) ? 0 : 1
					+ ((is_same<A5 ,void_t>::result) ? 0 : 1
					+ ((is_same<A6 ,void_t>::result) ? 0 : 1
					+ ((is_same<A7 ,void_t>::result) ? 0 : 1
					+ ((is_same<A8 ,void_t>::result) ? 0 : 1
					+ ((is_same<A9 ,void_t>::result) ? 0 : 1
					+ ((is_same<A10,void_t>::result) ? 0 : 1
					))))))))))
	};
};

///	�w�肳�ꂽ�������Ɩ߂�l�ɓK������functor�N���X�̌^��Ԃ�
template<class R, class A>
struct get_functor_type {
	typedef R result_type;
	typedef A arguments_type;

	template<int n> struct inner;
	template<> struct inner<0> { typedef typename select_type<is_same<result_type,void>::result, functor_nr0<result_type,arguments_type>, functor_r0<result_type,arguments_type> >::type	type; };
	template<> struct inner<1> { typedef typename select_type<is_same<result_type,void>::result, functor_nr1<result_type,arguments_type>, functor_r1<result_type,arguments_type> >::type	type; };
	template<> struct inner<2> { typedef typename select_type<is_same<result_type,void>::result, functor_nr2<result_type,arguments_type>, functor_r2<result_type,arguments_type> >::type	type; };
	template<> struct inner<3> { typedef typename select_type<is_same<result_type,void>::result, functor_nr3<result_type,arguments_type>, functor_r3<result_type,arguments_type> >::type	type; };
	template<> struct inner<4> { typedef typename select_type<is_same<result_type,void>::result, functor_nr4<result_type,arguments_type>, functor_r4<result_type,arguments_type> >::type	type; };
	template<> struct inner<5> { typedef typename select_type<is_same<result_type,void>::result, functor_nr5<result_type,arguments_type>, functor_r5<result_type,arguments_type> >::type	type; };
	template<> struct inner<6> { typedef typename select_type<is_same<result_type,void>::result, functor_nr6<result_type,arguments_type>, functor_r6<result_type,arguments_type> >::type	type; };
	template<> struct inner<7> { typedef typename select_type<is_same<result_type,void>::result, functor_nr7<result_type,arguments_type>, functor_r7<result_type,arguments_type> >::type	type; };
	template<> struct inner<8> { typedef typename select_type<is_same<result_type,void>::result, functor_nr8<result_type,arguments_type>, functor_r8<result_type,arguments_type> >::type	type; };
	template<> struct inner<9> { typedef typename select_type<is_same<result_type,void>::result, functor_nr9<result_type,arguments_type>, functor_r9<result_type,arguments_type> >::type	type; };
	template<> struct inner<10>{ typedef typename select_type<is_same<result_type,void>::result, functor_nr10<result_type,arguments_type>, functor_r10<result_type,arguments_type> >::type	type; };
	//	11�ȏ��������͒ǉ����Ă˂�

	//\	���]�݂�Functor�̌^
	typedef typename inner<arguments_type::args_num>::type type;
};

} // end of namespace YTLdelegate
} // end of namespace YTL
} // end of namespace yaneuraoGameSDK3rd

#endif	//	USE_yaneSDKdelegate
#endif	//	_MSC_VER

#endif // __YTL_DELEGATE_FUNCTOR_HPP__
