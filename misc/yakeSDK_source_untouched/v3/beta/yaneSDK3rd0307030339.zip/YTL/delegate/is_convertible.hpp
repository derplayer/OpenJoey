/**
 *	Type Convertibility Testing Template Class
 *	programmed by ENRA		'03/06/23
 */

#ifndef __YTL_DELEGATE_IS_CONVERTIBLE_HPP__
#define __YTL_DELEGATE_IS_CONVERTIBLE_HPP__

#ifdef USE_yaneSDKdelegate
#ifdef _MSC_VER

#include "yes_no_type.hpp"
#include "select_type.hpp"

namespace yaneuraoGameSDK3rd {
namespace YTL {
namespace YTLdelegate {

///	From�^��To�^�ɕϊ��o����Ȃ�true��result�l�Ƃ��ĕԂ�
template<typename From,typename To>
class is_convertible
{
	inline static yes_type check(To);
	inline static no_type check(...);
	inline static From makeFrom();
public:
	enum { result = sizeof(check(makeFrom()))==sizeof(yes_type), };
	typedef typename select_type<result, yes_type, no_type>::type type;
};
template<> class is_convertible<void, void>
{
public:
	enum { result = 1, };
	typedef yes_type type;
};

} // end of namespace YTLdelegate
} // end of namespace YTL
} // end of namespace yaneuraoGameSDK3rd

#endif	//	USE_yaneSDKdelegate
#endif	//	_MSC_VER

#endif // __YTL_DELEGATE_IS_CONVERTIBLE_HPP__
