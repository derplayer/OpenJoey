#ifndef __HEADERFORBCB_H__
#define __HEADERFORBCB_H__

//	BCB�Ȃ��..
#if defined (__BORLANDC__ )
#include "../AppFrame/stdafx.h"
#endif

#endif
