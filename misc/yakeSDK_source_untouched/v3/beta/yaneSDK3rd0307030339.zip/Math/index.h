
//	includes..

#include "yaneRound.h"					//	for RoundDiv/RoundRShift
#include "yaneSinTable.h"				//	for sin table
#include "yaneRand.h"					//	for random
#include "yaneCounter.h"				//	for RootCounter

