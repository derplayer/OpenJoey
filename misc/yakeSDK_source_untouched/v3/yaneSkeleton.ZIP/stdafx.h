#include "../yaneSDK/AppFrame/stdafx.h"
#include "../yaneSDK/yaneSDK.h"
